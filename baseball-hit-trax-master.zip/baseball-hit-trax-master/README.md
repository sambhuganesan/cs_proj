# Baseball Hit-Trax
Made for our AP CS final project with @monpon and @coolmath2018

Three part project: 
1. Using computer vision, track a baseball's location and feed its coordinates / size to another file
2. Calculate the ball's projected path 
3. Graph the ball and its path on a 3D GUI - we decided to do this part by scratch. 

Our presentation slides: https://docs.google.com/presentation/d/1La78hRCw2GB_KKVV9J4klkPI8mMj1uxeEPcz1EdUOcQ/edit?usp=sharing
